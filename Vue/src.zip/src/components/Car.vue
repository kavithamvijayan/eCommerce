<template>
    <h1>I am car component</h1>
</template>
<script>
export default {
    name: "Car"
}
</script>