<template>
    <h1>I am comment</h1>
</template>
<script>
import axios from 'axios'
import VueAxios from 'vue-axios'
export default {
    name: "Review",
     components:{
        axios,
        VueAxios
    }
    
}
</script>